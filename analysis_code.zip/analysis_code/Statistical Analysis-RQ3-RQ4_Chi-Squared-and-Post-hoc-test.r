# https://github.com/ebbertd/chisq.posthoc.test
install.packages("devtools")
devtools::install_github("ebbertd/chisq.posthoc.test")
install.packages("rstatix")
library(rstatix)

install.packages("RVAideMemoire")
library(RVAideMemoire)

# RQ3 -> 3 dependent variables : how_to_present, sentiment, Dominant_tone , 
#        2 Independent variables: Agree_Usability, Agree_NielsenHeuristics

# ALL data
myData <- read.csv("/path/to/Data/All_Data_RQ3.csv")
# NotebookProjects data
myData <- read.csv("/path/to/Data/NotebookProjects_data_RQ3.csv")
# CodeEditorProjects data
myData <- read.csv("/path/to/Data/CodeEditorProjects_data_RQ3.csv")

chisq.test(myData$Agree_Usability,myData$how_to_present , correct = TRUE)
chisq.test(myData$Agree_NielsenHeuristics,myData$how_to_present , correct = TRUE)
chisq.test(myData$Agree_Usability,myData$Sentiment , correct = TRUE)
chisq.test(myData$Agree_NielsenHeuristics,myData$Sentiment , correct = TRUE)
chisq.test(myData$Agree_Usability,myData$Dominant_tone , correct = TRUE)
chisq.test(myData$Agree_NielsenHeuristics,myData$Dominant_tone , correct = TRUE)

contingency_table <- table(myData$how_to_present, myData$Agree_Usability )
contingency_table <- table(myData$how_to_present, myData$Agree_NielsenHeuristics)
contingency_table <- table(myData$Sentiment, myData$Agree_Usability )
contingency_table <- table(myData$Dominant_tone , myData$Agree_Usability)
contingency_table <- table(myData$Sentiment, myData$Agree_NielsenHeuristics)
contingency_table <- table(myData$Dominant_tone , myData$Agree_NielsenHeuristics )

contingency_table
mat <-c(5,1,3,2,0,31,13,520)
chisq.multcomp(mat, p.method = "bonferroni")

#######################


# RQ4 -> 1 dependent variable: author_association ,
#        1 Independent variable: Agree_usability_role
# 
# ALL data
myData <- read.csv("/path/to/Data/All_Data_RQ4.csv")
# NotebookProjects data
myData <- read.csv("/path/to/Data/NotebookProjects_data_RQ4.csv")
# CodeEditorProjects data
myData <- read.csv("/path/to/Data/CodeEditorProjects_data_RQ4.csv")

chisq.test(myData$Agree_usability_role,myData$author_association , correct = TRUE)
contingency_table <- table(myData$author_association, myData$Agree_usability_role )
contingency_table

mat <-c(15, 8 ,2,1, 10,4, 77, 28, 14,1162)
chisq.multcomp(mat, p.method = "bonferroni")